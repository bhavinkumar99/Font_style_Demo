//
//  AppDelegate.swift
//  Fancy_Font_Demo
//
//  Created by Setblue's iMac on 24/04/19.
//  Copyright © 2019 Setblue. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    fileprivate var arrFonts = [typeAliasDictionary]()
    fileprivate var arrKeyboardData = [typeAliasDictionary]()
    fileprivate var arrTextArtData = [typeAliasDictionary]()
   
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        if !GetSetModel.iskeyAlreadyExist(key: UD_ALL_CUSTOME_FONT) { self.addAllFonts() }
        return true
    }

    func addAllFonts() {
        func getData(strSmall: String,strCapital : String ,strName : String,isFontFree: Bool) -> typeAliasDictionary {
            func splitData(str : String) -> [String] {
                var arrData : [String] = [String]()
                for char1 in str { arrData.append("\(char1)") }
                return arrData
            }
            var dict = typeAliasDictionary()
            dict[KEY_FONT_STYLE] = strName as AnyObject
            dict[KEY_FONT_CHARCTERS_SMALL] = splitData(str: strSmall) as AnyObject
            dict[KEY_FONT_CHARCTERS_CAPITAL] = splitData(str: strCapital) as AnyObject
            dict[KEY_IS_FONT_FREE] = isFontFree as AnyObject
            return dict
        }
        arrFonts.append(getData(strSmall: "ⓐⓑⓒⓓⓔⓕⓖⓗⓘⓙⓚⓛⓜⓝⓞⓟⓠⓡⓢⓣⓤⓥⓦⓧⓨⓩ", strCapital: "ⒶⒷⒸⒹⒺⒻⒼⒽⒾⒿⓀⓁⓂⓃⓄⓅⓆⓇⓈⓉⓊⓋⓌⓍⓎⓏ", strName: "Hollow Circle", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "🅐🅑🅒🅓🅔🅕🅖🅗🅘🅙🅚🅛🅜🅝🅞🅟🅠🅡🅢🅣🅤🅥🅦🅧🅨🅩", strCapital: "🅐🅑🅒🅓🅔🅕🅖🅗🅘🅙🅚🅛🅜🅝🅞🅟🅠🅡🅢🅣🅤🅥🅦🅧🅨🅩", strName: "Fill Circle", isFontFree: false))
        
        var dict : typeAliasDictionary = getData(strSmall: "ᴀʙᴄᴅᴇғɢʜɪᴊᴋʟᴍɴᴏᴘǫʀsᴛᴜᴠᴡxʏᴢ", strCapital: "ᴀʙᴄᴅᴇғɢʜɪᴊᴋʟᴍɴᴏᴘǫʀsᴛᴜᴠᴡxʏᴢ", strName: "Simple Small Caps", isFontFree: true)
        arrFonts.append(dict)
        dict[KEY_SELECTED_KEYBOARD] = "" as AnyObject
        GetSetModel.setCustomObjToUserDefaultsInExtenion(CustomeObj: dict as AnyObject, ForKey: UD_SELECTED_FONT_KEYBOARD)
        
        arrFonts.append(getData(strSmall: "₳฿₵ĐɆ₣₲ⱧłJ₭Ⱡ₥₦Ø₱QⱤ₴₮ɄV₩ӾɎⱫ", strCapital: "₳฿₵ĐɆ₣₲ⱧłJ₭Ⱡ₥₦Ø₱QⱤ₴₮ɄV₩ӾɎⱫ", strName: "Currency Caps", isFontFree: true))
        
        arrFonts.append(getData(strSmall: "𝕒𝕓𝕔𝕕𝕖𝕗𝕘𝕙𝕚𝕛𝕜𝕝𝕞𝕟𝕠𝕡𝕢𝕣𝕤𝕥𝕦𝕧𝕨𝕩𝕪𝕫", strCapital: "𝔸𝔹ℂ𝔻𝔼𝔽𝔾ℍ𝕀𝕁𝕂𝕃𝕄ℕ𝕆ℙℚℝ𝕊𝕋𝕌𝕍𝕎𝕏𝕐ℤ", strName: "Double Lines", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "𝔞𝔟𝔠𝔡𝔢𝔣𝔤𝔥𝔦𝔧𝔨𝔩𝔪𝔫𝔬𝔭𝔮𝔯𝔰𝔱𝔲𝔳𝔴𝔵𝔶𝔷", strCapital: "𝔄𝔅ℭ𝔇𝔈𝔉𝔊ℌℑ𝔍𝔎𝔏𝔐𝔑𝔒𝔓𝔔ℜ𝔖𝔗𝔘𝔙𝔚𝔛𝔜ℨ", strName: "Old English", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "𝖆𝖇𝖈𝖉𝖊𝖋𝖌𝖍𝖎𝖏𝖐𝖑𝖒𝖓𝖔𝖕𝖖𝖗𝖘𝖙𝖚𝖛𝖜𝖝𝖞𝖟", strCapital: "𝕬𝕭𝕮𝕯𝕰𝕱𝕲𝕳𝕴𝕵𝕶𝕷𝕸𝕹𝕺𝕻𝕼𝕽𝕾𝕿𝖀𝖁𝖂𝖃𝖄𝖅", strName: "Bold Old English", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "αвcdєfghíjklmnσpqrstuvwхчz", strCapital: "αв¢∂єfgнιנкℓмиσρqяѕтυνωχуz", strName: "Paranormal", isFontFree: true))
        
        arrFonts.append(getData(strSmall: "𝓪𝓫𝓬𝓭𝓮𝓯𝓰𝓱𝓲𝓳𝓴𝓵𝓶𝓷𝓸𝓹𝓺𝓻𝓼𝓽𝓾𝓿𝔀𝔁𝔂𝔃", strCapital: "𝓐𝓑𝓒𝓓𝓔𝓕𝓖𝓗𝓘𝓙𝓚𝓛𝓜𝓝𝓞𝓟𝓠𝓡𝓢𝓣𝓤𝓥𝓦𝓧𝓨𝓩", strName: "Bold Writing", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "ΔβCDΣҒGHIJҜLMΠΩPQRSTU∇ᗯXΨZ", strCapital: "ΔβCDΣҒGHIJҜLMΠΩPQRSTU∇ᗯXΨZ", strName: "Capital straight", isFontFree: true))
        
        arrFonts.append(getData(strSmall: "A͚B͚C͚D͚E͚F͚G͚H͚I͚J͚K͚L͚M͚N͚O͚P͚Q͚R͚S͚T͚U͚V͚W͚X͚Y͚Z͚", strCapital: "A͚B͚C͚D͚E͚F͚G͚H͚I͚J͚K͚L͚M͚N͚O͚P͚Q͚R͚S͚T͚U͚V͚W͚X͚Y͚Z͚", strName: "Capital Infinity", isFontFree: true))
        
        
        arrFonts.append(getData(strSmall: "αႦƈԃҽϝɠԋιʝƙʅɱɳσρϙɾʂƚυʋɯxყȥ", strCapital: "ABCDEFGHIJKLMNOPQRSTUVWXYZ", strName: "Simple Writing", isFontFree: true))
        
        arrFonts.append(getData(strSmall: "𝘢𝘣𝘤𝘥𝘦𝘧𝘨𝘩𝘪𝘫𝘬𝘭𝘮𝘯𝘰𝘱𝘲𝘳𝘴𝘵𝘶𝘷𝘸𝘹𝘺𝘻", strCapital: "𝘈𝘉𝘊𝘋𝘌𝘍𝘎𝘏𝘐𝘑𝘒𝘓𝘔𝘕𝘖𝘗𝘘𝘙𝘚𝘛𝘜𝘝𝘞𝘟𝘠𝘡", strName: "Simple Italic", isFontFree: true))
        
        arrFonts.append(getData(strSmall: "𝙖𝙗𝙘𝙙𝙚𝙛𝙜𝙝𝙞𝙟𝙠𝙡𝙢𝙣𝙤𝙥𝙦𝙧𝙨𝙩𝙪𝙫𝙬𝙭𝙮𝙯", strCapital: "𝘼𝘽𝘾𝘿𝙀𝙁𝙂𝙃𝙄𝙅𝙆𝙇𝙈𝙉𝙊𝙋𝙌𝙍𝙎𝙏𝙐𝙑𝙒𝙓𝙔𝙕", strName: "Bold Italic", isFontFree: true))
        
        arrFonts.append(getData(strSmall: "𝚊𝚋𝚌𝚍𝚎𝚏𝚐𝚑𝚒𝚓𝚔𝚕𝚖𝚗𝚘𝚙𝚚𝚛𝚜𝚝𝚞𝚟𝚠𝚡𝚢𝚣", strCapital: "𝙰𝙱𝙲𝙳𝙴𝙵𝙶𝙷𝙸𝙹𝙺𝙻𝙼𝙽𝙾𝙿𝚀𝚁𝚂𝚃𝚄𝚅𝚆𝚇𝚈𝚉", strName: "Mono Style", isFontFree: true))
        
        arrFonts.append(getData(strSmall: "ǟɮƈɖɛʄɢɦɨʝӄʟʍռօքզʀֆȶʊʋաӼʏʐ", strCapital: "ǟɮƈɖɛʄɢɦɨʝӄʟʍռօքզʀֆȶʊʋաӼʏʐ", strName: "Horror Style", isFontFree: true))
        
        arrFonts.append(getData(strSmall: "a̶b̶c̶d̶e̶f̶g̶h̶i̶j̶k̶l̶m̶n̶o̶p̶q̶r̶s̶t̶u̶v̶w̶x̶y̶z̶", strCapital: "A̶B̶C̶D̶E̶F̶G̶H̶I̶J̶K̶L̶M̶N̶O̶P̶Q̶R̶S̶T̶U̶V̶W̶X̶Y̶Z̶", strName: "Strike Line", isFontFree: true))
        
        arrFonts.append(getData(strSmall: "a̴b̴c̴d̴e̴f̴g̴h̴i̴j̴k̴l̴m̴n̴o̴p̴q̴r̴s̴t̴u̴v̴w̴x̴y̴z̴", strCapital: "A̴B̴C̴D̴E̴F̴G̴H̴I̴J̴K̴L̴M̴N̴O̴P̴Q̴R̴S̴T̴U̴V̴W̴X̴Y̴Z̴", strName: "Strike Tilde", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "a̷b̷c̷d̷e̷f̷g̷h̷i̷j̷k̷l̷m̷n̷o̷p̷q̷r̷s̷t̷u̷v̷w̷x̷y̷z̷", strCapital: "A̷B̷C̷D̷E̷F̷G̷H̷I̷J̷K̷L̷M̷N̷O̷P̷Q̷R̷S̷T̷U̷V̷W̷X̷Y̷Z̷", strName: "Strike Slash", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "a̲b̲c̲d̲e̲f̲g̲h̲i̲j̲k̲l̲m̲n̲o̲p̲q̲r̲s̲t̲u̲v̲w̲x̲y̲z̲", strCapital: "A̲B̲C̲D̲E̲F̲G̲H̲I̲J̲K̲L̲M̲N̲O̲P̲Q̲R̲S̲T̲U̲V̲W̲X̲Y̲Z̲", strName: "Single Underline", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "ᗩᗷᑕᗪEᖴGᕼIᒍKᒪᗰᑎOᑭᑫᖇᔕTᑌᐯᗯ᙭Yᘔ", strCapital: "ᗩᗷᑕᗪEᖴGᕼIᒍKᒪᗰᑎOᑭᑫᖇᔕTᑌᐯᗯ᙭Yᘔ", strName: "Hollow Style", isFontFree: true))
        
        arrFonts.append(getData(strSmall: "a̾b̾c̾d̾e̾f̾g̾h̾i̾j̾k̾l̾m̾n̾o̾p̾q̾r̾s̾t̾u̾v̾w̾x̾y̾z̾", strCapital: "A̾B̾C̾D̾E̾F̾G̾H̾I̾J̾K̾L̾M̾N̾O̾P̾Q̾R̾S̾T̾U̾V̾W̾X̾Y̾Z̾", strName: "Upper Tilde", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "ḀḃḉḊḕḟḠḧḭjḲḶṁṆṏṖqṙṠṮṳṼẇẌẏẒ", strCapital: "ḀḂḈḊḔḞḠḦḬJḲḶṀṆṎṖQṘṠṮṲṼẆẌẎẒ", strName: "Dirty Knight", isFontFree: true))
        
        arrFonts.append(getData(strSmall: "🅰🅱🌜🌛🎗🎏🌀♓🎐🎷🎋👢〽️🎵⚽🅿️🍳🌱💲🌴⛎✅🔱❎🍸💤", strCapital: "🅰🅱🌜🌛🎗🎏🌀♓🎐🎷🎋👢〽️🎵⚽🅿️🍳🌱💲🌴⛎✅🔱❎🍸💤", strName: "Emoji Mashup", isFontFree: true))
        
        arrFonts.append(getData(strSmall: "ᏗᏰፈᎴᏋᎦᎶᏂᎥᏠᏦᏝᎷᏁᎧᎮᎤᏒᏕᏖᏬᏉᏇጀᎩፚ", strCapital: "ᏗᏰፈᎴᏋᎦᎶᏂᎥᏠᏦᏝᎷᏁᎧᎮᎤᏒᏕᏖᏬᏉᏇጀᎩፚ", strName: "Fairy Tail", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "🄰🄱🄲🄳🄴🄵🄶🄷🄸🄹🄺🄻🄼🄽🄾🄿🅀🅁🅂🅃🅄🅅🅆🅇🅈🅉", strCapital: "🄰🄱🄲🄳🄴🄵🄶🄷🄸🄹🄺🄻🄼🄽🄾🄿🅀🅁🅂🅃🅄🅅🅆🅇🅈🅉", strName: "Hollwo Boxed", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "ᴀʙᴄᴅᴇғɢʜɪᴊᴋʟᴍɴᴏᴘϙʀꜱᴛᴜᴠᴡxʏᴢ", strCapital: "ᴀʙᴄᴅᴇғɢʜɪᴊᴋʟᴍɴᴏᴘϙʀꜱᴛᴜᴠᴡxʏᴢ", strName: "Tiny Thin", isFontFree: true))
        
        arrFonts.append(getData(strSmall: "ɐqɔpǝɟƃɥıɾʞlɯuodbɹsʇnʌʍxʎz", strCapital: "ɐqɔpǝɟƃɥıɾʞlɯuodbɹsʇnʌʍxʎz", strName: "UpSide DownSide", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "a̺b̺c̺d̺e̺f̺g̺h̺i̺j̺k̺l̺m̺n̺o̺p̺q̺r̺s̺t̺u̺v̺w̺x̺y̺z̺", strCapital: "A̺B̺C̺D̺E̺F̺G̺H̺I̺J̺K̺L̺M̺N̺O̺P̺Q̺R̺S̺T̺U̺V̺W̺X̺Y̺Z̺", strName: "DownSide Bracket", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "a͙b͙c͙d͙e͙f͙g͙h͙i͙j͙k͙l͙m͙n͙o͙p͙q͙r͙s͙t͙u͙v͙w͙x͙y͙z͙", strCapital: "A͙B͙C͙D͙E͙F͙G͙H͙I͙J͙K͙L͙M͙N͙O͙P͙Q͙R͙S͙T͙U͙V͙W͙X͙Y͙Z͙", strName: "DownSide Star", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "a̟b̟c̟d̟e̟f̟g̟h̟i̟j̟k̟l̟m̟n̟o̟p̟q̟r̟s̟t̟u̟v̟w̟x̟y̟z̟", strCapital: "A̟B̟C̟D̟E̟F̟G̟H̟I̟J̟K̟L̟M̟N̟O̟P̟Q̟R̟S̟T̟U̟V̟W̟X̟Y̟Z̟", strName: "DownSide Plus", isFontFree: true))
        
        arrFonts.append(getData(strSmall: "a͓̽b͓̽c͓̽d͓̽e͓̽f͓̽g͓̽h͓̽i͓̽j͓̽k͓̽l͓̽m͓̽n͓̽o͓̽p͓̽q͓̽r͓̽s͓̽t͓̽u͓̽v͓̽w͓̽x͓̽y͓̽z͓̽", strCapital: "A͓̽B͓̽C͓̽D͓̽E͓̽F͓̽G͓̽H͓̽I͓̽J͓̽K͓̽L͓̽M͓̽N͓̽O͓̽P͓̽Q͓̽R͓̽S͓̽T͓̽U͓̽V͓̽W͓̽X͓̽Y͓̽Z͓̽", strName: "UpDown Cross", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "a͎b͎c͎d͎e͎f͎g͎h͎i͎j͎k͎l͎m͎n͎o͎p͎q͎r͎s͎t͎u͎v͎w͎x͎y͎z͎", strCapital: "A͎B͎C͎D͎E͎F͎G͎H͎I͎J͎K͎L͎M͎N͎O͎P͎Q͎R͎S͎T͎U͎V͎W͎X͎Y͎Z͎", strName: "DownSide Arrow", isFontFree: false))
        
        
        
        arrFonts.append(getData(strSmall: "ᎪbᏟᎠᎬfᎶhᎥjᏦᏞmᏁᎾᏢqᏒsᏆuᏉᎳxᎽᏃ", strCapital: "ᎪbᏟᎠᎬfᎶhᎥjᏦᏞmᏁᎾᏢqᏒsᏆuᏉᎳxᎽᏃ", strName: "Magic Bridge", isFontFree: true))
        
        arrFonts.append(getData(strSmall: "卂乃匚ᗪ乇千Ꮆ卄丨ﾌҜㄥ爪几ㄖ卩Ɋ尺丂ㄒㄩᐯ山乂ㄚ乙", strCapital: "卂乃匚ᗪ乇千Ꮆ卄丨ﾌҜㄥ爪几ㄖ卩Ɋ尺丂ㄒㄩᐯ山乂ㄚ乙", strName: "Chinese Style", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "ᏗᏰፈᎴᏋᎦᎶᏂᎥᏠᏦᏝᎷᏁᎧᎮᎤᏒᏕᏖᏬᏉᏇጀᎩፚ", strCapital: "ᏗᏰፈᎴᏋᎦᎶᏂᎥᏠᏦᏝᎷᏁᎧᎮᎤᏒᏕᏖᏬᏉᏇጀᎩፚ", strName: "Pirates Style", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "ค๒ς๔єŦﻮђเןкl๓ภ๏קợгรtยשฬץאz", strCapital: "ค๒ς๔єŦﻮђเןкl๓ภ๏קợгรtยשฬץאz", strName: "Old Pirates Style", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "ДᏰℂ∂ƎƒᎶℍîʝƘℓℳИøρǪЯƧ✞υϑᏔ✘УՀ", strCapital: "ДᏰℂ∂ƎƒᎶℍîʝƘℓℳИøρǪЯƧ✞υϑᏔ✘УՀ", strName: "Mega Mix Style", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "ꍏꌃꉓꀸꍟꎇꁅꃅꀤꀭꀘ꒒ꎭꈤꂦᖘꆰꋪꌗ꓄ꀎᐯꅏꊼꌩꁴ", strCapital: "ꍏꌃꉓꀸꍟꎇꁅꃅꀤꀭꀘ꒒ꎭꈤꂦᖘꆰꋪꌗ꓄ꀎᐯꅏꊼꌩꁴ", strName: "Baby Style", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "ᕱც꒝Ꭰꂅꊰg♅ᎥϳКլოภԾᎵգᏒᏕϮuᏉᎳꊼᎩᏃ", strCapital: "ᕱც꒝Ꭰꂅꊰg♅ᎥϳКլოภԾᎵգᏒᏕϮuᏉᎳꊼᎩᏃ", strName: "Bold Baby Style", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "ԹՅՇԺȝԲԳɧɿʝƙʅʍՌԾρφՐՏԵՄעաՃՎՀ", strCapital: "ԹՅՇԺȝԲԳɧɿʝƙʅʍՌԾρφՐՏԵՄעաՃՎՀ", strName: "Old Egypt", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "ﾑ乃ᄃり乇ｷムんﾉﾌズﾚﾶ刀のｱゐ尺丂ｲひ√Wﾒﾘ乙", strCapital: "ﾑ乃ᄃり乇ｷムんﾉﾌズﾚﾶ刀のｱゐ尺丂ｲひ√Wﾒﾘ乙", strName: "Old Chinese", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "ค๖¢໓ēfງhiวkl๓ຖ໐p๑rŞtนงຟxฯຊ", strCapital: "ค๖¢໓ēfງhiวkl๓ຖ໐p๑rŞtนงຟxฯຊ", strName: "Old Portuguese", isFontFree: true))
        
        arrFonts.append(getData(strSmall: "ąცƈɖɛʄɠɧıʝƙƖɱŋơ℘զཞʂɬų۷ῳҳყʑ", strCapital: "ąცƈɖɛʄɠɧıʝƙƖɱŋơ℘զཞʂɬų۷ῳҳყʑ", strName: "Thin Tiny mix", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "𝔸ⓑ℃đｅŦ𝐆ᕼ𝕚ј𝓴𝓵ᗰη𝐨Ⓟ𝕢𝓻ѕ𝓣𝐮vώ𝔵Ўz", strCapital: "𝔸ⓑ℃đｅŦ𝐆ᕼ𝕚ј𝓴𝓵ᗰη𝐨Ⓟ𝕢𝓻ѕ𝓣𝐮vώ𝔵Ўz", strName: "Critical Mix", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "Ａ𝒷Ćᗪ𝒆𝐅قнเןＫＬⓂŇ𝓸𝓅𝓺ŕ𝐬丅ᑌ𝐯𝓦᙭ㄚŽ", strCapital: "Ａ𝒷Ćᗪ𝒆𝐅قнเןＫＬⓂŇ𝓸𝓅𝓺ŕ𝐬丅ᑌ𝐯𝓦᙭ㄚŽ", strName: "Critical Capital Mix", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "zʎxʍʌnʇsɹbdouɯlʞɾıɥɓɟǝpɔqɐ", strCapital: "Z⅄XMΛ∩⊥SᴚΌԀONW˥⋊ſIH⅁ℲƎᗡƆᙠ∀", strName: "DownSide Reverse", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "ƹʏxwvuƚꙅɿpqoᴎm|ʞꞁiʜǫᎸɘbɔdɒ", strCapital: "ƸYXWVUTꙄЯỌꟼOͶM⅃⋊ႱIHᎮꟻƎᗡƆᙠA", strName: "DownSide Thin Reverse", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "ᵃᵇᶜᵈᵉᶠᵍʰⁱʲᵏˡᵐⁿᵒᵖqʳˢᵗᵘᵛʷˣʸᶻ", strCapital: "ᴬᴮᶜᴰᴱᶠᴳᴴᴵᴶᴷᴸᴹᴺᴼᴾQᴿˢᵀᵁⱽᵂˣʸᶻ", strName: "Small Large Mix", isFontFree: true))
        
        arrFonts.append(getData(strSmall: "𝐚𝐛𝐜𝐝𝐞𝐟𝐠𝐡𝐢𝐣𝐤𝐥𝐦𝐧𝐨𝐩𝐪𝐫𝐬𝐭𝐮𝐯𝐰𝐱𝐲𝐳", strCapital: "𝐀𝐁𝐂𝐃𝐄𝐅𝐆𝐇𝐈𝐉𝐊𝐋𝐌𝐍𝐎𝐏𝐐𝐑𝐒𝐓𝐔𝐕𝐖𝐗𝐘𝐙", strName: "Regular Bold", isFontFree: true))
        
        arrFonts.append(getData(strSmall: "ΛBᄃDΣFGΉIJKᄂMПӨPQЯƧƬЦVЩXYZ", strCapital: "ΛBᄃDΣFGΉIJKᄂMПӨPQЯƧƬЦVЩXYZ", strName: "Confuse Mix", isFontFree: true))
        
        arrFonts.append(getData(strSmall: "αв¢∂єƒgнιנкℓмησρqяѕтυνωχуz", strCapital: "αв¢∂єƒgнιנкℓмησρqяѕтυνωχуz", strName: "Alpha Beta", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "åß¢Ðê£ghïjklmñðþqr§†µvwx¥z", strCapital: "ÄßÇÐÈ£GHÌJKLMñÖþQR§†ÚVW×¥Z", strName: "Alpha Beta Mix", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "卂乃匚ᗪ乇千Ꮆ卄丨ﾌҜㄥ爪几ㄖ卩Ɋ尺丂ㄒㄩᐯ山乂ㄚ乙", strCapital: "卂乃匚ᗪ乇千Ꮆ卄丨ﾌҜㄥ爪几ㄖ卩Ɋ尺丂ㄒㄩᐯ山乂ㄚ乙", strName: "Classic Chinese", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "ａｂｃｄｅｆｇｈｉｊｋｌｍｎｏｐｑｒｓｔｕｖｗｘｙｚ", strCapital: "ＡＢＣＤＥＦＧＨＩＪＫＬＭＮＯＰＱＲＳＴＵＶＷＸＹＺ", strName: "Extra Thin", isFontFree: true))
        
        arrFonts.append(getData(strSmall: "a҉b҉c҉d҉e҉f҉g҉h҉i҉j҉k҉l҉m҉n҉o҉p҉q҉r҉s҉t҉u҉v҉w҉x҉y҉z҉", strCapital: "A҉B҉C҉D҉E҉F҉G҉H҉I҉J҉K҉L҉M҉N҉O҉P҉Q҉R҉S҉T҉U҉V҉W҉X҉Y҉Z҉", strName: "Jungle Mix", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "ąҍçժҽƒցհìʝҟӀʍղօքզɾʂէմѵա×վՀ", strCapital: "ąҍçժҽƒցհìʝҟӀʍղօքզɾʂէմѵա×վՀ", strName: "Line-dot Mix", isFontFree: true))
        
        arrFonts.append(getData(strSmall: "Ⱥβ↻ᎠƐƑƓǶįلҠꝈⱮហටφҨའϚͲԱỼచჯӋɀ", strCapital: "Ⱥβ↻ᎠƐƑƓǶįلҠꝈⱮហටφҨའϚͲԱỼచჯӋɀ", strName: "Caps Line-dot", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "ά乃ｃ𝒹𝐄𝒻قђι𝔧Ҝ𝓁ｍ𝓷𝕆𝐏𝓠𝕣𝔰Ť𝓤Ｖ𝔀𝓧ⓨz", strCapital: "𝐚βＣＤ𝓔Ｆ𝐆𝒽ⓘј𝔨𝔩Ｍ𝓃ᗝⓟɊｒ𝕊tＵ𝓥ⓦˣ𝓎𝕫", strName: "Maths Mix", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "ᗩ𝐛匚ⓓ€𝐟𝕘нＩ𝒿𝓀𝓁𝔪ｎᵒρ𝓺尺ˢt𝓊ｖŴＸү𝕫", strCapital: "Ａвcⓓᵉ𝓕𝔤Ⓗ丨ｊ𝓀𝐥мＮｏⓟ𝓺ＲＳᵗยνŴˣ𝔂z", strName: "Rise And Fall", isFontFree: true))
        
        arrFonts.append(getData(strSmall: "𝔞ᵇ𝓬∂𝓔ƒｇĤƗڶｋĻ𝓶𝓷𝓸ρｑяｓ𝓽𝓾𝓥ʷ𝔁ʸ𝐙", strCapital: "𝔸в𝐜∂єŦⓖℍĮ𝐉ᵏĻ𝓶η𝓞ᵖ𝐪𝓡ⓢᵗยⓥ𝔴ˣ𝔶ℤ", strName: "Chess Move", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "𝓐ᵇⒸ๔ＥＦｇｈ𝒾ｊҜＬмŇ𝓞קℚ𝕣ŞтǗשⓌｘƳz", strCapital: "𝓐ᵇⒸ๔ＥＦｇｈ𝒾ｊҜＬмŇ𝓞קℚ𝕣ŞтǗשⓌｘƳz", strName: "Up Down Mix", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "ค𝔟ｃ𝔻乇千Ꮆ𝒽𝓲𝓳кℓ𝓶ภ𝕆ρ𝐪𝓻Ⓢ𝓽ᑌ𝓥ω𝐗ㄚ𝔷", strCapital: "𝔸ᗷς𝐝ᵉғ𝓖нᶤⒿⓀ𝕃мᑎᗝ𝓅ɊᖇŜＴ𝕦𝕧𝔴᙭𝐘Ⓩ", strName: "Hot Fire", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "α๒𝓒๔єℱg𝐡𝐈𝐉𝓀ℓ𝓶几ㄖⓅ𝔮𝔯s𝐓ｕνＷЖ𝓎ｚ", strCapital: "ᗩＢ𝕔ⒹεＦ𝐠ђƗ𝕁𝓚ℓⓜภㄖᑭq𝕣𝕊𝕋𝓊𝐯ⓦＸ𝐘𝕫", strName: "Kings Maker", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "a⃟b⃟c⃟d⃟e⃟f⃟g⃟h⃟i⃟j⃟k⃟l⃟m⃟n⃟o⃟p⃟q⃟r⃟s⃟t⃟u⃟v⃟w⃟x⃟y⃟z⃟", strCapital: "A⃟B⃟C⃟D⃟E⃟F⃟G⃟H⃟I⃟J⃟K⃟L⃟M⃟N⃟O⃟P⃟Q⃟R⃟S⃟T⃟U⃟V⃟W⃟X⃟Y⃟Z⃟", strName: "Diamond Style", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "𝐚в𝒸𝒹εｆᵍђ𝐢𝕁ｋ𝔩𝕄𝐍ㄖƤ𝕢Ⓡ𝐬Ｔยν𝔀𝐗чŽ", strCapital: "Ａ𝓫Ć∂εℱق𝔥𝕀𝕛𝕂ℓＭŇόρ𝔮Ř𝕊𝕥ＵᵛωｘⓨⓏ", strName: "Small Caps Mix", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "ⓐⒷ¢𝓓ᗴｆقĦιʲķl𝓜ℕᵒ𝐏ⓠ𝐫𝐒Ť𝕦VŴＸчz", strCapital: "คβᑕ𝔡𝑒𝐟Ꮆ𝐡𝕚𝐉𝕂ℓ𝐦𝔫ⓄＰq𝓇𝓼тย𝐯𝓦ˣ¥𝐙 ", strName: "Musical Night", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "𝕒βⒸ∂ＥᶠĞ𝔥ᶤ𝓙𝐊ｌ𝔪𝐧σקǪŘs𝓉ỮⓋωｘｙ𝓩", strCapital: "𝕒βⒸ∂ＥᶠĞ𝔥ᶤ𝓙𝐊ｌ𝔪𝐧σקǪŘs𝓉ỮⓋωｘｙ𝓩", strName: "River Flows", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "𝒶𝔟匚∂Ⓔ𝐅Ｇ𝕙ᶤנкŁ𝐦ภⓞｐqяรᵗ𝓊ＶŴ᙭𝕐𝕫", strCapital: "ΔⒷℂＤ𝐞ŦⒼħᶤ𝕛ⓚˡｍ𝐧𝕆𝐏𝓠ᖇ𝐬Ⓣυ𝕧Ｗx𝕪𝔷", strName: "Font Fight", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "ᗑßℂᗪᗴᖴǤℌÏℑᛕⱢᗰᑎ۝ƤɊ℟ᔕƬ℧℣ѾﾒƳƵ", strCapital: "ᗑßℂᗪᗴᖴǤℌÏℑᛕⱢᗰᑎ۝ƤɊ℟ᔕƬ℧℣ѾﾒƳƵ", strName: "System Font 1", isFontFree: true))
        
        arrFonts.append(getData(strSmall: "მჩეძპfცhἶქκlოῆõρგΓჰནυὗwჯყɀ", strCapital: "მჩეძპfცhἶქκlოῆõρგΓჰནυὗwჯყɀ", strName: "System Font 2", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "ﻪъ८ժεքցհﻨյĸlოռթզгรէսνա〤կչε", strCapital: "ﻪъ८ժεքցհﻨյĸlოռթզгรէսνա〤կչε", strName: "System Font 3", isFontFree: true))
        
        arrFonts.append(getData(strSmall: "⒜⒝⒞⒟⒠⒡⒢⒣⒤⒥⒦⒧⒨⒩⒪⒫⒬⒭⒮⒯⒰⒱⒲⒳⒴⒵", strCapital: "⒜⒝⒞⒟⒠⒡⒢⒣⒤⒥⒦⒧⒨⒩⒪⒫⒬⒭⒮⒯⒰⒱⒲⒳⒴⒵", strName: "Round Brecket", isFontFree: true))
        
        arrFonts.append(getData(strSmall: "Ωbҫ₫ҼҒᏩӈأᏧҠӀ₥ӣoҎգԻֆҭմ∨ഢҲұℤ", strCapital: "Ωbҫ₫ҼҒᏩӈأᏧҠӀ₥ӣoҎգԻֆҭմ∨ഢҲұℤ", strName: "Omega Mix", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "ඹദඋd౯ቱ൭իiժḳໄጦn0ᎵqṛގᎢᏌކ௰ץYՁ", strCapital: "ඹദඋd౯ቱ൭իiժḳໄጦn0ᎵqṛގᎢᏌކ௰ץYՁ", strName: "South Indian Style", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "ก⊾₡Ꭰe℉GᖺIᙴkL₥₦࿋ཥqའᔓ₮u⊽௶᙭yz", strCapital: "ก⊾₡Ꭰe℉GᖺIᙴkL₥₦࿋ཥqའᔓ₮u⊽௶᙭yz", strName: "Degree Radius", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "ᗋ฿℃ᗠЄҒԌӉіјҠしᗰท◎թҨГՏҬԱᗐᗯӼүՀ", strCapital: "ᗋ฿℃ᗠЄҒԌӉіјҠしᗰท◎թҨГՏҬԱᗐᗯӼүՀ", strName: "Degree Radius Caps", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "ÁßČĎĔŦĞĤĨĴĶĹМŃŐРQŔŚŤÚVŴЖŶŹ", strCapital: "ÁßČĎĔŦĞĤĨĴĶĹМŃŐРQŔŚŤÚVŴЖŶŹ", strName: "Upper Weight Caps", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "@฿©ᖱ⺕Ⅎᕥ♄ꀧวkᘂ๓₦፨℗q®ᔓ꓄มvฟxຯʐ", strCapital: "@฿©ᖱ⺕Ⅎᕥ♄ꀧวkᘂ๓₦፨℗q®ᔓ꓄มvฟxຯʐ", strName: "Black Magic", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "ѦѣСԀЄҒԌӉіјҠLӍИѺթҨГՏҬԱѶЩӼүՀ", strCapital: "ѦѣСԀЄҒԌӉіјҠLӍИѺթҨГՏҬԱѶЩӼүՀ", strName: "Black Magic Caps", isFontFree: false))
        
        
        arrFonts.append(getData(strSmall: "∀ᗹcↁ℈ᎸgᏥɨjḲḷʍn￮pqＲṩṬṳṽᗯ᙭ẏʑ", strCapital: "∀ᗹcↁ℈ᎸgᏥɨjḲḷʍn￮pqＲṩṬṳṽᗯ᙭ẏʑ", strName: "Wrong Side Caps", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "คB८D૯F૭HɿJқLɱN૦PqRʂTυVωXעZ", strCapital: "คB८D૯F૭HɿJқLɱN૦PqRʂTυVωXעZ", strName: "Latter And Number", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "🅰🅱🅲🅳🅴🅵🅶🅷🅸🅹🅺🅻🅼🅽🅾🅿🆀🆁🆂🆃🆄🆅🆆🆇🆈🆉", strCapital: "🅰🅱🅲🅳🅴🅵🅶🅷🅸🅹🅺🅻🅼🅽🅾🅿🆀🆁🆂🆃🆄🆅🆆🆇🆈🆉", strName: "Boxed Caps", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "abc∂efghijklmno℘q𝓇stuvωאָℽ𝓏", strCapital: "abc∂efghijklmno℘q𝓇stuvωאָℽ𝓏", strName: "Small Catelog", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "α多cdefghijҜlmno℘qℝstuv𝖜xyչ", strCapital: "α多cdefghijҜlmno℘qℝstuv𝖜xyչ", strName: "Small Free Fire", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "∀BɔDƎℲ⅁HIſ⋊⅂WᴎOԀΌᴚS⊥∩ᴧMX⅄Z", strCapital: "∀BɔDƎℲ⅁HIſ⋊⅂WᴎOԀΌᴚS⊥∩ᴧMX⅄Z", strName: "Down Caps Mix", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "@฿ςÐΞךּĝĦ¡∂қĺmמθÞΘя§‡טעשּׂЖצּζ", strCapital: "@฿ςÐΞךּĝĦ¡∂қĺmמθÞΘя§‡טעשּׂЖצּζ", strName: "Maths Logic", isFontFree: false))
        
        arrFonts.append(getData(strSmall: "ªƁƈƊǝƑǤhƗjkŁ៣Ɲᢩ‽ƣƦsŧuvƜ※yẔ", strCapital: "ªƁƈƊǝƑǤhƗjkŁ៣Ɲᢩ‽ƣƦsŧuvƜ※yẔ", strName: "Caps Small mix", isFontFree: false))
        GetSetModel.setCustomObjToUserDefaultsInSystem(CustomeObj: arrFonts as AnyObject, ForKey: UD_ALL_CUSTOME_FONT)
        GetSetModel.setCustomObjToUserDefaultsInExtenion(CustomeObj: arrFonts as AnyObject, ForKey: UD_ALL_CUSTOME_FONT)
        
    }
    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }

    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }


}

