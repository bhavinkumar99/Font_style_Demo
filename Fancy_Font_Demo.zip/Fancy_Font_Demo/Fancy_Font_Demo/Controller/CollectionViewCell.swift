//
//  CollectionViewCell.swift
//  Fancy_Font_Demo
//
//  Created by Setblue's iMac on 03/05/19.
//  Copyright © 2019 Setblue. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var imageCollection: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
