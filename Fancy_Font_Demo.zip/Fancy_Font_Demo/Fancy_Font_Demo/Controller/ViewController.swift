//
//  ViewController.swift
//  Fancy_Font_Demo
//
//  Created by Setblue's iMac on 24/04/19.
//  Copyright © 2019 Setblue. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
 
    fileprivate var arrKeyboardList = [typeAliasDictionary]()
    
    let arr = ["A","B","C","D","E","F"]
    let arr1 = ["g","g","j","u","t","t"]
    let arr2 = ["t","t","l","y","5","p"]
    @IBOutlet weak var SegMent: UISegmentedControl!
    @IBOutlet weak var TableView: UITableView!
    @IBOutlet var collection: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        collection.delegate = self
        collection.dataSource = self
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
  
    self.collection.register(UINib.init(nibName: "CollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "CollectionViewCell")
//    self.TableView.register(UINib.init(nibName: "KeyboardCell", bundle: nil), forCellReuseIdentifier: "KeyboardCell")
        var dict = typeAliasDictionary()
        dict[KEY_DESIGN_NAME] = "KEYBOARD_THEME_1" as AnyObject
        dict[KEY_BTN_BORDER_COLOR] = UIColor.black as AnyObject
        dict[KEY_BTN_BG_COLOR] = UIColor.white as AnyObject
        dict[KEY_FONT_COLOR] = UIColor.black as AnyObject
        dict[KEY_IS_KEYBOARD_FREE] = true as AnyObject
        arrKeyboardList.append(dict)
        
        dict[KEY_DESIGN_NAME] = "KEYBOARD_THEME_2" as AnyObject
        dict[KEY_BTN_BORDER_COLOR] = UIColor.white as AnyObject
        dict[KEY_BTN_BG_COLOR] = UIColor.clear as AnyObject
        dict[KEY_FONT_COLOR] = UIColor.white as AnyObject
        dict[KEY_IS_KEYBOARD_FREE] = true as AnyObject
        arrKeyboardList.append(dict)
        
        dict[KEY_DESIGN_NAME] = "KEYBOARD_THEME_3" as AnyObject
        dict[KEY_BTN_BORDER_COLOR] = UIColor.clear as AnyObject
        dict[KEY_BTN_BG_COLOR] = UIColor.white as AnyObject
        dict[KEY_FONT_COLOR] = UIColor.black as AnyObject
        dict[KEY_IS_KEYBOARD_FREE] = true as AnyObject
        arrKeyboardList.append(dict)
        
        dict[KEY_DESIGN_NAME] = "KEYBOARD_THEME_4" as AnyObject
        dict[KEY_BTN_BORDER_COLOR] = UIColor.white as AnyObject
        dict[KEY_BG_IMAGE] = #imageLiteral(resourceName: "icon_LockFont")
        dict[KEY_KEYBOARD_BG_IMAGE] = #imageLiteral(resourceName: "image_KBG_1")
        dict[KEY_BTN_BG_COLOR] = UIColor.clear as AnyObject
        dict[KEY_FONT_COLOR] = UIColor.white as AnyObject
        dict[KEY_IS_KEYBOARD_FREE] = false as AnyObject
        arrKeyboardList.append(dict)
        
        dict[KEY_DESIGN_NAME] = "KEYBOARD_THEME_5" as AnyObject
        dict[KEY_BTN_BORDER_COLOR] = UIColor.clear as AnyObject
        dict[KEY_BG_IMAGE] = #imageLiteral(resourceName: "icon_LockFont")
        dict[KEY_KEYBOARD_BG_IMAGE] = #imageLiteral(resourceName: "image_KBG_10")
        dict[KEY_BTN_BG_COLOR] = UIColor.white.withAlphaComponent(0.25) as AnyObject
        dict[KEY_FONT_COLOR] = UIColor.white as AnyObject
        dict[KEY_IS_KEYBOARD_FREE] = false as AnyObject
        arrKeyboardList.append(dict)
        
        dict[KEY_DESIGN_NAME] = "KEYBOARD_THEME_6" as AnyObject
        dict[KEY_BTN_BORDER_COLOR] = UIColor.white as AnyObject
        dict[KEY_BG_IMAGE] = #imageLiteral(resourceName: "icon_LockFont")
        dict[KEY_KEYBOARD_BG_IMAGE] = #imageLiteral(resourceName: "image_KBG_8")
        dict[KEY_BTN_BG_COLOR] = UIColor.clear as AnyObject
        dict[KEY_FONT_COLOR] = UIColor.black as AnyObject
        dict[KEY_IS_KEYBOARD_FREE] = false as AnyObject
        arrKeyboardList.append(dict)
        
        dict[KEY_DESIGN_NAME] = "KEYBOARD_THEME_7" as AnyObject
        dict[KEY_BTN_BORDER_COLOR] = UIColor.clear as AnyObject
        dict[KEY_BG_IMAGE] = #imageLiteral(resourceName: "icon_LockFont")
        dict[KEY_KEYBOARD_BG_IMAGE] = #imageLiteral(resourceName: "image_KBG_6")
        dict[KEY_BTN_BG_COLOR] = UIColor.white.withAlphaComponent(0.25) as AnyObject
        dict[KEY_FONT_COLOR] = UIColor.black as AnyObject
        dict[KEY_IS_KEYBOARD_FREE] = false as AnyObject
        arrKeyboardList.append(dict)
        
        dict[KEY_DESIGN_NAME] = "KEYBOARD_THEME_8" as AnyObject
        dict[KEY_BTN_BORDER_COLOR] = UIColor.clear as AnyObject
        dict[KEY_BG_IMAGE] = #imageLiteral(resourceName: "icon_LockFont")
        dict[KEY_KEYBOARD_BG_IMAGE] = #imageLiteral(resourceName: "image_KBG_3")
        dict[KEY_BTN_BG_COLOR] = UIColor.white.withAlphaComponent(0.25) as AnyObject
        dict[KEY_FONT_COLOR] = UIColor.white as AnyObject
        dict[KEY_IS_KEYBOARD_FREE] = false as AnyObject
        arrKeyboardList.append(dict)
        
        dict[KEY_DESIGN_NAME] = "KEYBOARD_THEME_9" as AnyObject
        dict[KEY_BTN_BORDER_COLOR] = UIColor.red as AnyObject
        dict[KEY_BG_IMAGE] = #imageLiteral(resourceName: "icon_LockFont")
        dict[KEY_KEYBOARD_BG_IMAGE] = #imageLiteral(resourceName: "image_KBG_4")
        dict[KEY_BTN_BG_COLOR] = UIColor.white.withAlphaComponent(0.25) as AnyObject
        dict[KEY_FONT_COLOR] = UIColor.red as AnyObject
        dict[KEY_IS_KEYBOARD_FREE] = false as AnyObject
        arrKeyboardList.append(dict)
        
        dict[KEY_DESIGN_NAME] = "KEYBOARD_THEME_10" as AnyObject
        dict[KEY_BTN_BORDER_COLOR] = UIColor.clear as AnyObject
        dict[KEY_BG_IMAGE] = #imageLiteral(resourceName: "icon_LockFont")
        dict[KEY_KEYBOARD_BG_IMAGE] = #imageLiteral(resourceName: "image_KBG_2")
        dict[KEY_BTN_BG_COLOR] = UIColor.white.withAlphaComponent(0.25) as AnyObject
        dict[KEY_FONT_COLOR] = UIColor.white as AnyObject
        dict[KEY_IS_KEYBOARD_FREE] = false as AnyObject
        arrKeyboardList.append(dict)
        
        dict[KEY_DESIGN_NAME] = "KEYBOARD_THEME_11" as AnyObject
        dict[KEY_BTN_BORDER_COLOR] = UIColor.clear as AnyObject
        dict[KEY_BG_IMAGE] = #imageLiteral(resourceName: "icon_LockFont")
        dict[KEY_KEYBOARD_BG_IMAGE] = #imageLiteral(resourceName: "image_KBG_11")
        dict[KEY_BTN_BG_COLOR] = UIColor.white.withAlphaComponent(0.25) as AnyObject
        dict[KEY_FONT_COLOR] = UIColor.white as AnyObject
        dict[KEY_IS_KEYBOARD_FREE] = false as AnyObject
        arrKeyboardList.append(dict)
        
        dict[KEY_DESIGN_NAME] = "KEYBOARD_THEME_12" as AnyObject
        dict[KEY_BTN_BORDER_COLOR] = UIColor.clear as AnyObject
        dict[KEY_BG_IMAGE] = #imageLiteral(resourceName: "icon_LockFont")
        dict[KEY_KEYBOARD_BG_IMAGE] = #imageLiteral(resourceName: "image_KBG_9")
        dict[KEY_BTN_BG_COLOR] = UIColor.white.withAlphaComponent(0.25) as AnyObject
        dict[KEY_FONT_COLOR] = UIColor.black as AnyObject
        dict[KEY_IS_KEYBOARD_FREE] = false as AnyObject
        arrKeyboardList.append(dict)
        
        dict[KEY_DESIGN_NAME] = "KEYBOARD_THEME_13" as AnyObject
        dict[KEY_BTN_BORDER_COLOR] = UIColor.clear as AnyObject
        dict[KEY_BG_IMAGE] = #imageLiteral(resourceName: "icon_LockFont")
        dict[KEY_KEYBOARD_BG_IMAGE] = #imageLiteral(resourceName: "image_KBG_7")
        dict[KEY_BTN_BG_COLOR] = UIColor.black.withAlphaComponent(0.25) as AnyObject
        dict[KEY_FONT_COLOR] = UIColor.white as AnyObject
        dict[KEY_IS_KEYBOARD_FREE] = false as AnyObject
        arrKeyboardList.append(dict)
        
        dict[KEY_DESIGN_NAME] = "KEYBOARD_THEME_14" as AnyObject
        dict[KEY_BTN_BORDER_COLOR] = UIColor.white as AnyObject
        dict[KEY_BG_IMAGE] = #imageLiteral(resourceName: "icon_LockFont")
        dict[KEY_KEYBOARD_BG_IMAGE] = #imageLiteral(resourceName: "image_KBG_3")
        dict[KEY_BTN_BG_COLOR] = UIColor.clear as AnyObject
        dict[KEY_FONT_COLOR] = UIColor.white as AnyObject
        dict[KEY_IS_KEYBOARD_FREE] = false as AnyObject
        arrKeyboardList.append(dict)
        collection.reloadData()
        TableView.reloadData()
    }
   
    @IBAction func btnSegmentAction(_ sender: UISegmentedControl) {
        if SegMent.selectedSegmentIndex == 0 {
            TableView.isHidden = false
            collection.isHidden = true
            TableView.reloadData()
        }else{
            collection.isHidden = false
            TableView.isHidden = true
            collection.reloadData()
        }
    }
}
extension ViewController: UICollectionViewDelegate,UICollectionViewDataSource {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrKeyboardList.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell : CollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionViewCell", for: indexPath)as! CollectionViewCell
        
        return cell
    }
}
extension ViewController: UITableViewDelegate,UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 3
         }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return arr.count
        }else if section == 1 {
            return arr1.count
        }else{
            return arr2.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        TableView.register(UITableViewCell.self, forCellReuseIdentifier: "KeyboardCell")
        let cell  = tableView.dequeueReusableCell(withIdentifier: "KeyboardCell", for: indexPath)
        //    let dict : typeAliasDictionary = arrKeyboardList[indexPath.section]
        if indexPath.section == 0 {
            cell.textLabel?.text = arr[indexPath.row]
            
        }else if indexPath.section == 1{
            cell.textLabel?.text = arr1[indexPath.row]
        }else if indexPath.section == 2{
            cell.textLabel?.text = arr2[indexPath.row]
        }
        return cell
    }
   func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
           if section == 0 {
              return "hello"
        }else if section == 1{
            return "Word"
        }else{
            return "final"
        }
        return ""
    }
}
