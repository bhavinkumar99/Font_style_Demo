//
//  FontCell.swift
//  Fancy_Font_Demo
//
//  Created by Setblue's iMac on 07/05/19.
//  Copyright © 2019 Setblue. All rights reserved.
//

import UIKit

class FontCell: UITableViewCell {

    
   
    @IBOutlet weak var imageFont: UIImageView!
    @IBOutlet weak var lblFontStyleStates: UILabel!
    @IBOutlet weak var lblFontName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
